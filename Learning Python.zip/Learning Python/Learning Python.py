import collections

#Exercise 1: opening and using a file

fh = open(r"C:\Users\Abdul\OneDrive\Desktop\Hello World.txt")
for line in  fh:
    print("read: %s" % line, end="")

fh.close


#Exercise 2: counting word in a file
fh = open(r"C:\Users\Abdul\OneDrive\Desktop\Hello World.txt")

num_words = 0
for line in fh:
    words=line.split()
    num_words = num_words + len(words)

print (" I got %d words" % num_words)
fh.close

#Exercise 3: exception handling - context manager "with"

try:
    
    with open(r"C:\Users\Abdul\OneDrive\Desktop\Hello World.txt") as fh:
        
        for line in fh:
            words = line.split()
            num_words += len(words)


except OSError as e:
    print("error %d reading file %s" % (e.errno, e.filename))
    


print("I got %d words" % num_words)

#Exercise 4: word frequency counter

try:

    fh = open(r"C:\Users\Abdul\OneDrive\Desktop\Hello World.txt")
except OSError as e:
    print("error %d reading file %s" % (e.errno, e.filename)) 
    quit()

num_words = 0
word_freq = collections.Counter()
for line in fh:
    words = line.split()
    num_words += len(words)
    for word in words:
        word_freq[word] += 1
fh.close()

print(" I got %d words" % num_words)
for key in sorted(word_freq.keys() ):
    print("key %-12s found %2d times" % (key, word_freq[key]) )

print("Order by frequency descending")
for key in sorted(word_freq, key=word_freq.get,reverse=True):
    print("key %-12s found %2d times" % (key, word_freq[key]) )

# Exercise 5: using functions

def open_File():
    fh = None
    try:
        fh = open(r"C:\Users\Abdul\OneDrive\Desktop\Hello World.txt")
    except OSError as e:
        print("error %d reading file %s" % (e.errno, e.filename)) 
        quit()
    return fh

def process_File(fh):
    num_words = 0
    word_freq = collections.Counter()
    for line in fh:
        words = line.split()
        num_words += len(words)
        for word in words:
            word_freq[word] += 1
    fh.close()
    return num_words, word_freq

def print_report(num_words:int, word_freq: dict):
    print("I got %d words" % num_words)

    for key in sorted(word_freq.keys() ):
        print("key %-12s found %2d times" % (key, word_freq[key]) )

def main():
    fh = open_File()
    (nw, wf) = process_File(fh)
    print_report(nw, wf)

if __name__ == "__main__":
    main()






